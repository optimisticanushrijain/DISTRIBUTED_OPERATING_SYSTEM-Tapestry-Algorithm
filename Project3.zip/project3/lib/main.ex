defmodule Project.Main do
  # use GenServer

  # def start_link(arg) do
  #   GenServer.start_link(__MODULE__, arg)
  # end

  def start([numNodes, numRequests]) do
    start_time = System.monotonic_time(:millisecond)
    nodeIDs = Project.Nodes.NodeID.generateNodeIds([], numNodes)
    # mapping nodes with node IDs
    {node_list, superPid} = createNodes(nodeIDs)

    Enum.map(node_list, fn current_node ->
      pid = elem(current_node, 1)

      for target_node <- node_list -- [current_node],
          do: Project.Nodes.Worker.setNeighbors(pid, current_node, target_node)

      # Project.Nodes.NodeID.setRoutingTablesForEachNode(node, node_list -- [node])
    end)


    infiniteLoop(start_time, node_list)

    routing(node_list, numRequests)




    # IO.inspect(final_nodes)


    # {:ok, [numNodes, numRequests]}
  end

    def routing(node_list, numRequests) do
      Enum.each(node_list, fn x->
        pid = elem(x, 1)
        # IO.inspect pid

        invokeRequest(pid, numRequests, node_list)


      end)
    end

    def invokeRequest(pid, numRequests, node_list) do



      Enum.each(1..numRequests, fn x->
        destID = Enum.random(node_list)
        GenServer.cast(pid, {:invokeRequest, destID, node_list})
      end)

    end

  defp infiniteLoop(start_time, nodes_list) do
    successfullySetNeighbor =
      Enum.filter(nodes_list, fn node ->
        node_pid = elem(node, 1)
        Project.Nodes.Worker.getState(node_pid, :set_neighbor_success)
      end)

    # IO.inspect({"#######:", successfullySetNeighbor} )
    if(length(successfullySetNeighbor) == length(nodes_list)) do
      end_time = System.monotonic_time(:millisecond)
      #IO.inspect("Starting")
    #  IO.inspect(end_time - start_time)
      # {:ok, file} = File.open("output", [:write])

      finalState =
        Enum.map(nodes_list, fn node ->
          node_pid = elem(node, 1)
          Project.Nodes.Worker.getState(node_pid, nil)
        end)
        IO.inspect("Tables created")
      # IO.inspect(finalState)
      end_time - start_time
    else
      infiniteLoop(start_time, nodes_list)
    end
  end

  def createNodes(nodeIDs) do
    {:ok, superPid} = Project.Nodes.Supervisor.start_link(nodeIDs)
    node_worker_list = Supervisor.which_children(superPid)
    node_list = Enum.map(node_worker_list, fn {id, pid, _, _} -> {id, pid} end)
    {node_list, superPid}
  end
end
