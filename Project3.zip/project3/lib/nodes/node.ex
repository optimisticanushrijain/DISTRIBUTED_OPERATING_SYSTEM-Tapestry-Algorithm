defmodule Project.Nodes.Worker do
  use GenServer

  def start_link(arg) do
    GenServer.start_link(__MODULE__, arg)
  end

  def init(arg) do
    # IO.inspect(Process.info(self()))
    state = %{}
    state = Map.put(state, :NodeID, List.first(arg))
    state = Map.put(state, :finalList, [])
    number_of_digits = Project.Nodes.NodeID.numberOfDigits()
    digits = Project.Nodes.NodeID.digits()
    # neighbor_map = %{}

    neighbor_map =
      for num_of_digit <- 0..(number_of_digits - 1),
          into: %{},
          do: {num_of_digit, %{}}

    # IO.inspect(neighbor_map)

    neighbor_map =
      for {key, _levelMap} <- neighbor_map,
          into: %{} do
        newLevel = for(digit <- digits, into: %{}, do: {digit, []})
        {key, newLevel}
      end

    state = Map.put(state, :neighbor_map, neighbor_map)

    # IO.inspect(state)
    # IO.inspect("inint")
    {:ok, state}
  end

  def getState(pid, key) do
    GenServer.call(pid, {:getState, key}, :infinity)
  end

  def setNeighbors(pid, currentNode, node) do
    GenServer.cast(pid, {:setNeighbors, currentNode, node})
  end

  def sendMessage(pid, currentNode, node) do
    GenServer.cast(pid, {:sendMessage, currentNode, node})
  end

  def handle_call({:getState, key}, _from, state) do
    # IO.inspect(key)

    if(key == nil) do
      {:reply, state, state}
    else
      {:reply, Map.get(state, key), state}
    end
  end

  def handle_cast({:setNeighbors, currentNode, node}, state) do
    # IO.inspect(currentNode)
    currentID = Atom.to_string(elem(currentNode, 0))
    targetID = Atom.to_string(elem(node, 0))

    neighbor_map = Map.get(state, :neighbor_map)

    level = Project.Nodes.NodeID.matchNodeIds(currentID, targetID, 0)

    mapIndex = String.at(targetID, level)
    levelMap = Map.get(neighbor_map, level)

    cellValue = Map.get(levelMap, mapIndex)

    levelMap =
      if(length(cellValue) == 0 ) do
        Map.put(levelMap, mapIndex, cellValue ++ [node])
      else
        levelMap
      end

    # IO.inspect(levelMap)
    neighbor_map = Map.put(neighbor_map, level, levelMap)
    state = Map.put(state, :neighbor_map, neighbor_map)
    # IO.inspect("levelMap")
    state = Map.put(state, :set_neighbor_success, true)

    # IO.inspect({neighbor_map, currentID, targetID}  )
    # IO.inspect(state)
    # IO.inspect("Print TStae")
#IO.inspect(Map.get(Map.get(neighbor_map, 0),"D"))

#Enum.each(["A","B","C","D","E","F"], fn x -> IO.inspect(Map.get(Map.get(neighbor_map, 0),x)) end)




    {:noreply, state}
  end

  def handle_cast({:invokeRequest, destID, node_list}, state) do
    node_a = Map.get(state, :NodeID)
    node_b = Atom.to_string(elem(destID,0))

   # IO.puts "#{node_a}   #{node_b} "
    i =  Project.Nodes.NodeID.matchNodeIds(node_a, node_b, 0)
    j = String.at(node_b, i)


   # IO.inspect j

    routingTable = Map.get(state, :neighbor_map)

   node_i = Map.get(Map.get(routingTable, i), j)
# IO.inspect(node_i)
    #  IO.inspect(pid_i)
    pid_i = elem(Enum.at(node_i, 0),1)
    GenServer.cast(pid_i, {:next_hop, node_b, 1})

    # IO.inspect destID
    {:noreply, state}
  end

  def handle_cast({:next_hop, node_b, hops}, state) do

    node_a = Map.get(state, :NodeID)
  #  node_b = Atom.to_string(elem(node_b,0))






    if(node_a == node_b) do
      IO.inspect({hops, "hops"})


    else
      i =  Project.Nodes.NodeID.matchNodeIds(node_a, node_b, 0)
      j = String.at(node_b, i)
      routingTable = Map.get(state, :neighbor_map)
      node_i = Map.get(Map.get(routingTable, i), j)

    # IO.inspect({node_a,node_b, node_i })
      pid_i = elem(Enum.at(node_i, 0),1)
   # IO.inspect(pid_i)


      GenServer.cast(pid_i, {:next_hop, node_b, hops+1})


    end

   {:noreply, state}
  end

end
