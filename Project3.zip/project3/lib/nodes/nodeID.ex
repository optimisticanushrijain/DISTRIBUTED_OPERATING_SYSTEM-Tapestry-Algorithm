defmodule Project.Nodes.NodeID do
  @digits ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F"]
  @numberOfDigits 8
  @neighborNumber 15

  def digits, do: @digits
  def numberOfDigits, do: @numberOfDigits

  def generateNodeIds(nodeIDs, numNodes) do
    id = []

    id =
      for _digit <- 1..@numberOfDigits do
        id ++ Enum.random(@digits)
      end

    nodeIDs = nodeIDs ++ [Enum.join(id, "")]

    nodeIDs = Enum.uniq(nodeIDs)

    nodeIDs =
      if(length(nodeIDs) != numNodes) do
        generateNodeIds(nodeIDs, numNodes)
      else
        nodeIDs
      end

    nodeIDs
  end

  def getDigitIndex(digit) do
    integer = Integer.parse(digit)

    finalInteger =
      if(integer == :error) do
        cond do
          digit == 'A' -> 10
          digit == 'B' -> 11
          digit == 'C' -> 12
          digit == 'D' -> 13
          digit == 'E' -> 14
          digit == 'F' -> 15
        end
      else
        elem(integer, 0)
      end

    finalInteger
  end

  def matchNodeIds(nodePrimary, nodeSecondary, position) do
    if(String.at(nodePrimary, position) == String.at(nodeSecondary, position)) do
      matchNodeIds(nodePrimary, nodeSecondary, position + 1)
    else
      if(position + 1 == @numberOfDigits) do
        position
      else
        position
      end
    end

    # trunc(String.bag_distance(nodePrimary, nodeSecondary) * @numberOfDigit)
  end

  # def setRoutingTablesForEachNode(currentNode, nodes) do
  #   neighbor = Map.new()
  #   neighbour = Enum.map(@digits, fn digit ->
  #     nil
  #   end)
  #   neighbor =
  #     for level <- 1..@numberOfDigits,
  #         do:
  #           Map.put(
  #             neighbor,
  #             Integer.to_string(level - 1),

  #           )

  #   nodes = Enum.shuffle(nodes)

  #   try do

  #     for node <- nodes, fn node ->
  #       nodeID = Atom.to_string(elem(node, 0))
  #       levelIndex = matchNodeIds(), Atom.to_string(elem(currentNode, 0)))
  #       matchIndex = getDigitIndex(String.at(nodeID, matchedIndex+1))
  #       if(neighbor.get(levelIndex)) do

  #       end
  #     end)
  #     for x <- [1, 2, 0, 3],
  #       do: if x == 0, do: throw(:break), else: x
  #   catch
  #     :break -> :broken
  #   end

  #   # Enum.filter(nodes, fn node ->
  #   #   # IO.inspect(Atom.to_string(elem(node, 0)))
  #   #   # matchNodeIds()
  #   #   IO.inspect(
  #   #     {String.starts_with?(
  #   #        Atom.to_string(elem(node, 0)),
  #   #        String.slice(Atom.to_string(elem(currentNode, 0)), 0, digit)
  #   #      ), Atom.to_string(elem(node, 0)), Atom.to_string(elem(currentNode, 0))}
  #   #   )

  #   #   String.starts_with?(
  #   #     Atom.to_string(elem(node, 0)),
  #   #     String.slice(Atom.to_string(elem(currentNode, 0)), 0, digit)
  #   #   )
  #   # end)
  #   IO.inspect(neighbor)

  #   # String.starts_with?("elixir", "eli")
  #   # newNodes = newNodes ++ [Enum.random(nodes)]
  #   # newNodes = Enum.uniq(newNodes)

  #   # newNodes =
  #   #   if(trunc(length(nodes) * @neighborNumber / 100) != length(newNodes)) do
  #   #     getRandomNodeNeighbors(newNodes, nodes)
  #   #   else
  #   #     newNodes
  #   #   end
  # end

  def getRandomNodeNeighbors(newNodes, nodes) do
    newNodes = newNodes ++ [Enum.random(nodes)]
    newNodes = Enum.uniq(newNodes)

    newNodes =
      if(trunc(length(nodes) * @neighborNumber / 100) != length(newNodes)) do
        getRandomNodeNeighbors(newNodes, nodes)
      else
        newNodes
      end
  end
end
