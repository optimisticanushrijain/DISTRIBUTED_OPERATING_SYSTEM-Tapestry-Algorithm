defmodule Project.Nodes.Supervisor do
  use Supervisor

  def start_link(nodeIDs) do
    Supervisor.start_link(__MODULE__, nodeIDs)
  end

  def init(nodeIDs) do
    # IO.puts(numberOfNodes)
    # parseArguments()
    # IO.puts("Supervisor creating nodes")

    children =
      for nodeId <- nodeIDs,
          into: [],
          do:
            Supervisor.child_spec({Project.Nodes.Worker, [nodeId]},
              id: String.to_atom(nodeId)
            )

    Supervisor.init(children, strategy: :one_for_one)
  end
end
