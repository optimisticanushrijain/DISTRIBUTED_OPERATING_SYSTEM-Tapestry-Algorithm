defmodule Project.Application do
  use Application

  def start(_type, [numNodes, numRequests]) do
    # Proj1.Supervisor.startFun()
    # IO.puts(topology)

    numNodes =
      if(String.valid?(numNodes)) do
        elem(Integer.parse(numNodes), 0)
      else
        numNodes
      end

    numRequests =
      if(String.valid?(numRequests)) do
        elem(Integer.parse(numRequests), 0)
      else
        numRequests
      end

    Project.Main.start([numNodes, numRequests])
  end
end
