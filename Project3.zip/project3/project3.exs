# [nodesNumber, topology, algorithm] = System.argv()

Project.Application.start(:normal, System.argv())
